"""
Shared helpers for the debug metadata parsers.

Self-contained on purpose: the debug subsystem ships inside the ``rainbow``
package, so it must not import the developer-only tools under ``tools/``.
"""


def decode_text(raw):
    """
    Decodes a metadata text blob whose encoding is not known in advance.

    Agilent/Waters sidecars are a mix of UTF-8, UTF-16LE, and UTF-16BE (often
    with a BOM, sometimes only inferable from interleaved NUL bytes). Returns a
    ``str`` decoded with the best-guess encoding, never raising.

    Args:
        raw (bytes): Raw file contents.

    Returns:
        Decoded text.

    """
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        enc = "utf-16"
    elif b"encoding=\"utf-16\"" in raw[:120].lower() \
            or b"encoding='utf-16'" in raw[:120].lower():
        enc = "utf-16"
    elif b"\x00" in raw[:64]:
        # No BOM, so the byte order is inferred from where the NULs fall. Text
        # in either order is mostly ASCII, whose high byte is NUL: little
        # endian puts it second (odd offsets), big endian first (even ones).
        # Guessing little endian for both turned every BOM-less UTF-16BE
        # sidecar into mojibake, which is not a decoding its docstring claims.
        sample = raw[:64]
        even = sample[0::2].count(0)
        odd = sample[1::2].count(0)
        enc = "utf-16-be" if even > odd else "utf-16-le"
    elif raw[:3] == b"\xef\xbb\xbf":
        enc = "utf-8-sig"
    else:
        enc = "utf-8"
    try:
        return raw.decode(enc)
    except UnicodeDecodeError:
        pass

    # The bytes are not the encoding they looked like. Decoding them with
    # "replace" instead would destroy exactly the characters worth recovering:
    # a Windows codepage byte becomes U+FFFD, so the copyright sign in a
    # Chemstation version banner, and any accent in an operator or sample name,
    # is lost rather than read. A single-byte codepage decodes one byte to one
    # character and cannot fail the way a multi-byte one does, so it is tried
    # first, cp1252 before latin-1 because these are Windows instrument files
    # and cp1252 is where the quotes and dashes in 0x80-0x9F live.
    #
    # Only where the bytes are not UTF-16-shaped. A truncated or slightly
    # malformed UTF-16 sidecar is still mostly readable with "replace", and
    # reading it one byte at a time would turn all of it into mojibake.
    if b"\x00" not in raw:
        for codepage in ("cp1252", "latin-1"):
            try:
                return raw.decode(codepage)
            except UnicodeDecodeError:
                continue
    return raw.decode(enc, "replace")


def require_lxml(etree, what):
    """
    Raises a clear error when a debug parser is used without lxml installed.

    The debug parsers recover structure from malformed and mis-encoded
    sidecars, which the standard library's parser cannot do, so lxml is a real
    requirement here rather than an accelerator. Callers pass the ``etree`` they
    imported, which is None when lxml is absent.

    Args:
        etree: The imported lxml etree module, or None.
        what (str): What the caller was trying to read, for the message.

    """
    if etree is None:
        raise ImportError(
            f"Reading {what} needs lxml, which recovers structure from the "
            f"malformed sidecars vendors write. rainbow installs it by "
            f"default, so this environment has had it removed; reinstall it "
            f"with 'pip install lxml'.")
